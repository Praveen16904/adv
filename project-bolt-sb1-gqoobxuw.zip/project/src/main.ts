import { Component } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter } from '@angular/router';
import { RouterOutlet } from '@angular/router';
import { routes } from './app/app.routes';

/**
 * Main App Component
 * Root component that contains the router outlet for navigation
 */
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  template: `
    <!-- Router outlet displays the current route component -->
    <router-outlet></router-outlet>
  `,
  styles: [`
    /* Global styles for the root component */
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `]
})
export class App {
  title = 'Grocery Store';
}

/**
 * Bootstrap the application with routing provider
 */
bootstrapApplication(App, {
  providers: [
    // Provide router with our defined routes
    provideRouter(routes)
  ]
}).catch(err => console.error(err));