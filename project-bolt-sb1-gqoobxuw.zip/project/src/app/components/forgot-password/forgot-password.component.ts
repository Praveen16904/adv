import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="auth-container">
      <div class="background-decoration">
        <div class="floating-shape shape-1"></div>
        <div class="floating-shape shape-2"></div>
        <div class="floating-shape shape-3"></div>
      </div>
      
      <div class="auth-card">
        <div class="auth-header">
          <div class="logo">
            <div class="logo-icon">🛒</div>
            <span class="logo-text">GroceryStore</span>
          </div>
          <h2>Reset Password</h2>
          <p class="subtitle">Don't worry! Enter your email and we'll send you reset instructions</p>
        </div>
        
        <form [formGroup]="forgotPasswordForm" (ngSubmit)="onSubmit()">
          <!-- Email Field -->
          <div class="form-group">
            <label for="email">Email Address</label>
            <div class="input-wrapper">
              <div class="input-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                  <polyline points="22,6 12,13 2,6"/>
                </svg>
              </div>
              <input 
                type="email" 
                id="email" 
                formControlName="email"
                class="form-control"
                placeholder="Enter your registered email"
                [class.error]="forgotPasswordForm.get('email')?.invalid && forgotPasswordForm.get('email')?.touched"
              >
            </div>
            <div class="error-message" *ngIf="forgotPasswordForm.get('email')?.invalid && forgotPasswordForm.get('email')?.touched">
              <span *ngIf="forgotPasswordForm.get('email')?.errors?.['required']">Email is required</span>
              <span *ngIf="forgotPasswordForm.get('email')?.errors?.['email']">Please enter a valid email</span>
            </div>
          </div>

          <!-- Submit Button -->
          <button 
            type="submit" 
            class="btn-primary pulse-on-hover"
            [disabled]="forgotPasswordForm.invalid || isSubmitting"
          >
            <span *ngIf="!isSubmitting">Send Reset Instructions</span>
            <span *ngIf="isSubmitting" class="loading-content">
              <svg class="loading-spinner" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-dasharray="31.416" stroke-dashoffset="31.416">
                  <animate attributeName="stroke-dasharray" dur="2s" values="0 31.416;15.708 15.708;0 31.416" repeatCount="indefinite"/>
                  <animate attributeName="stroke-dashoffset" dur="2s" values="0;-15.708;-31.416" repeatCount="indefinite"/>
                </circle>
              </svg>
              Sending Instructions...
            </span>
          </button>
        </form>

        <!-- Success Message -->
        <div class="success-message" *ngIf="emailSent">
          <div class="success-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path d="M9 12l2 2 4-4"/>
              <circle cx="12" cy="12" r="10"/>
            </svg>
          </div>
          <h3>Check Your Email!</h3>
          <p>We've sent password reset instructions to your email address. Please check your inbox and follow the link to reset your password.</p>
          <small>Didn't receive the email? Check your spam folder or try again.</small>
        </div>

        <!-- Navigation Links -->
        <div class="auth-links">
          <p class="back-prompt">
            Remember your password? 
            <a (click)="navigateTo('/sign-in')" class="link signin-link">Back to Sign In</a>
          </p>
          <p class="signup-prompt">
            Don't have an account? 
            <a (click)="navigateTo('/sign-up')" class="link signup-link">Create one here</a>
          </p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .auth-container {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      padding: 24px;
      position: relative;
      overflow: hidden;
    }

    .background-decoration {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 0;
    }

    .floating-shape {
      position: absolute;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(10px);
      animation: float 6s ease-in-out infinite;
    }

    .shape-1 {
      width: 90px;
      height: 90px;
      top: 25%;
      left: 15%;
      animation-delay: 0.5s;
    }

    .shape-2 {
      width: 110px;
      height: 110px;
      top: 65%;
      right: 20%;
      animation-delay: 2.5s;
    }

    .shape-3 {
      width: 75px;
      height: 75px;
      bottom: 25%;
      left: 25%;
      animation-delay: 4.5s;
    }

    @keyframes float {
      0%, 100% {
        transform: translateY(0px) rotate(0deg);
      }
      50% {
        transform: translateY(-15px) rotate(180deg);
      }
    }

    .auth-card {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      padding: 48px;
      border-radius: 24px;
      box-shadow: 
        0 20px 25px -5px rgba(0, 0, 0, 0.1),
        0 10px 10px -5px rgba(0, 0, 0, 0.04),
        0 0 0 1px rgba(255, 255, 255, 0.2);
      width: 100%;
      max-width: 440px;
      position: relative;
      z-index: 1;
      animation: fadeInUp 0.8s ease-out;
    }

    .auth-header {
      text-align: center;
      margin-bottom: 32px;
    }

    .logo {
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 24px;
      gap: 12px;
    }

    .logo-icon {
      font-size: 32px;
      background: var(--gradient-primary);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .logo-text {
      font-size: 24px;
      font-weight: 700;
      background: var(--gradient-primary);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    h2 {
      margin-bottom: 12px;
      color: var(--text-primary);
      font-size: 32px;
      font-weight: 700;
      letter-spacing: -0.025em;
    }

    .subtitle {
      color: var(--text-secondary);
      font-size: 16px;
      line-height: 1.4;
    }

    .form-group {
      margin-bottom: 24px;
    }

    label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
      color: var(--text-primary);
      font-size: 14px;
      letter-spacing: 0.025em;
    }

    .input-wrapper {
      position: relative;
    }

    .input-icon {
      position: absolute;
      left: 16px;
      top: 50%;
      transform: translateY(-50%);
      color: var(--text-light);
      z-index: 2;
    }

    .input-icon svg {
      width: 20px;
      height: 20px;
      stroke-width: 2;
    }

    .form-control {
      width: 100%;
      padding: 16px 16px 16px 48px;
      border: 2px solid var(--border-color);
      border-radius: 12px;
      font-size: 16px;
      font-weight: 400;
      box-sizing: border-box;
      background: var(--background-secondary);
      color: var(--text-primary);
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      position: relative;
    }

    .form-control:focus {
      border-color: var(--primary-color);
      box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.1);
      transform: translateY(-1px);
    }

    .form-control:focus + .input-icon {
      color: var(--primary-color);
    }

    .form-control.error {
      border-color: var(--error-color);
      box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
    }

    .error-message {
      color: var(--error-color);
      font-size: 13px;
      margin-top: 8px;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 4px;
    }

    .success-message {
      background: linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(5, 150, 105, 0.05) 100%);
      border: 2px solid var(--success-color);
      border-radius: 16px;
      padding: 24px;
      margin-top: 24px;
      text-align: center;
      animation: fadeInUp 0.6s ease-out;
    }

    .success-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 48px;
      height: 48px;
      background: var(--success-color);
      border-radius: 50%;
      margin-bottom: 16px;
      color: white;
    }

    .success-icon svg {
      width: 24px;
      height: 24px;
      stroke-width: 3;
    }

    .success-message h3 {
      color: var(--success-color);
      font-size: 20px;
      font-weight: 600;
      margin-bottom: 8px;
    }

    .success-message p {
      color: var(--text-primary);
      margin: 0;
      font-size: 15px;
      line-height: 1.5;
      margin-bottom: 8px;
    }

    .success-message small {
      color: var(--text-secondary);
      font-size: 13px;
    }

    .btn-primary {
      width: 100%;
      padding: 16px 24px;
      background: var(--gradient-primary);
      color: white;
      border: none;
      border-radius: 12px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      margin-top: 8px;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      position: relative;
      overflow: hidden;
      letter-spacing: 0.025em;
    }

    .btn-primary:hover:not(:disabled) {
      transform: translateY(-2px);
      box-shadow: var(--shadow-lg);
    }

    .pulse-on-hover:hover:not(:disabled) {
      animation: pulse 1.5s infinite;
    }

    .btn-primary:disabled {
      background: var(--text-light);
      cursor: not-allowed;
      transform: none;
      box-shadow: none;
    }

    .loading-content {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }

    .loading-spinner {
      width: 20px;
      height: 20px;
    }

    .auth-links {
      text-align: center;
      margin-top: 32px;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .link {
      color: var(--primary-color);
      cursor: pointer;
      text-decoration: none;
      font-weight: 600;
      transition: all 0.2s ease;
      position: relative;
    }

    .link::after {
      content: '';
      position: absolute;
      width: 0;
      height: 2px;
      bottom: -2px;
      left: 0;
      background: var(--primary-color);
      transition: width 0.3s ease;
    }

    .link:hover {
      color: var(--primary-dark);
    }

    .link:hover::after {
      width: 100%;
    }

    .back-prompt,
    .signup-prompt {
      color: var(--text-secondary);
      font-size: 14px;
      margin: 0;
    }

    .signup-link {
      color: var(--secondary-color);
    }

    .signup-link::after {
      background: var(--secondary-color);
    }
  `]
})
export class ForgotPasswordComponent {
  forgotPasswordForm: FormGroup;
  isSubmitting: boolean = false;
  emailSent: boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router
  ) {
    // Initialize the reactive form with validation rules
    this.forgotPasswordForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]]
    });
  }

  /**
   * Handle form submission
   */
  onSubmit(): void {
    if (this.forgotPasswordForm.valid) {
      const { email } = this.forgotPasswordForm.value;
      
      // Simulate API call with loading state
      this.isSubmitting = true;
      
      // Simulate network delay
      setTimeout(() => {
        console.log('Password reset requested for:', email);
        
        // Here you would typically call a password reset service
        this.isSubmitting = false;
        this.emailSent = true;
        
        // Reset form after successful submission
        this.forgotPasswordForm.reset();
      }, 2000);
    } else {
      // Mark all fields as touched to show validation errors
      this.forgotPasswordForm.markAllAsTouched();
    }
  }

  /**
   * Navigate to different routes
   */
  navigateTo(route: string): void {
    this.router.navigate([route]);
  }
}