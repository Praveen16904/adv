import { Routes } from '@angular/router';
import { SignInComponent } from './components/sign-in/sign-in.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';

/**
 * Application routing configuration
 * Defines the navigation paths for authentication pages
 */
export const routes: Routes = [
  // Redirect root path to sign-in page
  { path: '', redirectTo: '/sign-in', pathMatch: 'full' },
  
  // Authentication routes
  { path: 'sign-in', component: SignInComponent },
  { path: 'sign-up', component: SignUpComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  
  // Wildcard route - must be last
  // Redirects any unknown paths to sign-in
  { path: '**', redirectTo: '/sign-in' }
];